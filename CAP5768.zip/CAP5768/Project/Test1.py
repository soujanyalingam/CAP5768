
print (int(('12.0').split(".")[0]))