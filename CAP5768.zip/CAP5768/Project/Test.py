import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import cm
import matplotlib
import pandas as pd
import seaborn as sn
import csv
import os
import folium

import numpy as np
from sklearn.tree import DecisionTreeClassifier, export_graphviz
from os import system
import graphviz

filename = os.path.abspath("./data/data_small.csv")

input_data = pd.read_csv(filename, index_col='Date')
input_data.index = pd.to_datetime(input_data.index)

data_2017, data_2016, data_2015, data_2014 = input_data.loc['2017'], input_data.loc['2016'], input_data.loc['2015'], input_data.loc['2014']
data_2013, data_2012, data_2011, data_2010 = input_data.loc['2013'], input_data.loc['2012'], input_data.loc['2011'], input_data.loc['2010']
data_2009, data_2008, data_2007, data_2006 = input_data.loc['2009'], input_data.loc['2008'], input_data.loc['2007'], input_data.loc['2006']
data_2005, data_2004, data_2003, data_2002 = input_data.loc['2005'], input_data.loc['2004'], input_data.loc['2003'], input_data.loc['2002']
data_2001 = input_data.loc['2001']
'''
## Yearly crimes
arrest_yearly = input_data[input_data['Arrest'] == True]['Arrest']
plt.subplot()
# yearly arrest
arrest_yearly.resample('A').sum().plot()
plt.title('Yearly arrests')
plt.show()
# Monthly arrest
arrest_yearly.resample('M').sum().plot()
plt.title('Monthly arrests')
plt.show()
'''

# Domestic violence
domestic_yearly = input_data[input_data['Domestic'] == True]['Domestic']
plt.subplot()
# yearly domestic violence
domestic_yearly.resample('A').sum().plot()
plt.title('Yearly domestic violence')
plt.show()
# Monthly domestic violence
domestic_yearly.resample('M').sum().plot()
plt.title('Monthly domestic violence')
plt.show()


'''
#Top 5 crimes trend over the years

theft_2012 = pd.DataFrame(data_2012[data_2012['Primary Type'].isin(['THEFT','BATTERY', 'CRIMINAL DAMAGE', 'NARCOTICS', 'ASSAULT'])]['Primary Type'])
theft_2013 = pd.DataFrame(data_2013[data_2013['Primary Type'].isin(['THEFT','BATTERY', 'CRIMINAL DAMAGE', 'NARCOTICS', 'ASSAULT'])]['Primary Type'])
theft_2014 = pd.DataFrame(data_2014[data_2014['Primary Type'].isin(['THEFT','BATTERY', 'CRIMINAL DAMAGE', 'NARCOTICS', 'ASSAULT'])]['Primary Type'])
theft_2015 = pd.DataFrame(data_2015[data_2015['Primary Type'].isin(['THEFT','BATTERY', 'CRIMINAL DAMAGE', 'NARCOTICS', 'ASSAULT'])]['Primary Type'])
theft_2016 = pd.DataFrame(data_2016[data_2016['Primary Type'].isin(['THEFT','BATTERY', 'CRIMINAL DAMAGE', 'NARCOTICS', 'ASSAULT'])]['Primary Type'])

grouper = theft_2012.groupby([pd.TimeGrouper('M'), 'Primary Type'])
grouper_2013 = theft_2013.groupby([pd.TimeGrouper('M'), 'Primary Type'])
grouper_2014 = theft_2014.groupby([pd.TimeGrouper('M'), 'Primary Type'])
grouper_2015 = theft_2015.groupby([pd.TimeGrouper('M'), 'Primary Type'])
grouper_2016 = theft_2016.groupby([pd.TimeGrouper('M'), 'Primary Type'])

data1_2012 = grouper['Primary Type'].count().unstack()
data1_2013 = grouper_2013['Primary Type'].count().unstack()
data1_2014 = grouper_2014['Primary Type'].count().unstack()
data1_2015 = grouper_2015['Primary Type'].count().unstack()
data1_2016 = grouper_2016['Primary Type'].count().unstack()

data1_2012.plot()
plt.title("Top 5 monthly crimes in 2012")
plt.show()
'''